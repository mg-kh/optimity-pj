<?php

  require_once get_template_directory() . '/template-home.php';

?>