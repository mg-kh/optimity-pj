<?php

  get_header();

?>

<?php get_template_part( 'template-parts/page/content', 'page-banner' ); ?>

<?php get_template_part( 'template-parts/page/content', 'page-breadcrumb' ); ?>

<?php get_template_part( 'template-parts/page/content', 'page' ); ?>
     
<?php

  get_footer();

?>